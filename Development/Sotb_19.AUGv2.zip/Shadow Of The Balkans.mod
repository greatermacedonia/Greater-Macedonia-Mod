version="0.1"
tags={
	"Alternative History"
	"Events"
	"Gameplay"
	"Map"
	"National Focuses"
	"Translation"
	"Balance"
	"Sound"
}
name="Shadow Of The Balkans"
supported_version="1.19.2.0"
path="/home/oddsoul/.local/share/Paradox Interactive/Hearts of Iron IV/mod/Shadow Of The Balkans"