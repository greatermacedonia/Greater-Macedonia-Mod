version="0.1"
tags={
	"Alternative History"
	"Events"
	"Gameplay"
	"Map"
	"National Focuses"
	"Translation"
	"Balance"
	"Sound"
}
name="Shadow Of The Balkans"
supported_version="1.19.2.0"